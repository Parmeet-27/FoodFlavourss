<!-- login.php -->
<?php
// Assuming you have a MySQL database running with PHPMyAdmin

// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];

// Connect to the database
$servername = "localhost";  // Change this if your MySQL server is hosted elsewhere
$dbname = "newfoodflv";  // Replace with the name of your database
$dbusername = "root";  // Replace with your MySQL username
$dbpassword = "";  // Replace with your MySQL password

// Create a connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Perform database operations
// For example, you can query the users table
$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

// Check if the query was successful
if ($result->num_rows > 0) {
    // User exists, perform necessary actions
    echo "Login successful!";
} else {
    // User doesn't exist or invalid credentials
    echo "Invalid username or password.";
}

// Close the connection
$conn->close();
?>
