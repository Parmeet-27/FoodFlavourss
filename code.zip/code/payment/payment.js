function Online(){
    //alert("Successfully Registered!");
    window.open("onlinepayment.html");
}
function Cash(){
    window.open("index.html");
}