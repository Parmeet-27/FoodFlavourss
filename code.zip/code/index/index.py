import qrcode
qr_img=qrcode.make("C:\Users\parme\OneDrive\Desktop\DE_Project\code\code\index.html")
qr_img.save("qr-img1.png")