<?php

$username = "root";
$password = "";
$server = 'localhost';
$db = 'newfoodflv';

$conn = mysqli_connect($server,$username,$password,$db);

if($conn){
    echo "Connection successful";
}
else {
    die(" No connection".mysqli_connect_error());
}
?>